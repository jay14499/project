#include<stdio.h>
#define n 10
int main()
{
 int a[n],i,val;
 for(i=0;i<n;i++)
 {
	printf("enter the array elements a[%d]",i);
	scanf("%d",&a[i]);
 }
 printf("enter the element to be searched:");
 scanf("%d",&val);

 for(i=0;i<n;i++)
 {
  if(a[i]==val)
  {
   printf("the element %d found at a[%d]\n",val,i);
  }
 }
 printf("element not found\n");
}
